-- MySQL dump 10.19  Distrib 10.3.39-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: admin_people
-- ------------------------------------------------------
-- Server version	10.3.39-MariaDB-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `admins`
--

DROP TABLE IF EXISTS `admins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admins` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `email` varchar(191) NOT NULL,
  `password` varchar(191) NOT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `admins_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admins`
--

LOCK TABLES `admins` WRITE;
/*!40000 ALTER TABLE `admins` DISABLE KEYS */;
INSERT INTO `admins` VALUES (1,'Admin','alexinter16@gmail.com','$2y$10$59ak2MP.xWZh6RV/2eL1qudO2fS/Dl9aVOklOax4WnSJinM2d1Cwy','tKy3rUXu0FaRt3VrigaCCD3pDjsDALiqPIy1HVNV1P2mOrzZyUstwjXRLfAj',NULL,'2024-07-08 17:43:40'),(2,'oxigenoglobal','dawinos@gmail.com','$2y$10$1S3PHUOj2Uiw15FLaKbQOejqpPJMoZ9xwiGD/je5/onbknYAB3ovy','RUdPC7Xx0UZPBnWbn7zKqYVzy5ZLdWBiyT6bcc1lIpw4UZxBTkWPAxtCO9ji',NULL,'2020-05-15 16:08:32'),(3,'alain','guardcolombia@gmail.com','$2y$10$r3jSS904pDqMe/vS4T474.MiLbMJ1uIblfV/fxqS6BY0WMVN4ljkq','pu5YpMCeziBUUZ96qpUGuhMA6O8cRXGyYEBxh1qoRu7gpKppZk1q6hBueyTs',NULL,NULL);
/*!40000 ALTER TABLE `admins` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bonus_redeems`
--

DROP TABLE IF EXISTS `bonus_redeems`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bonus_redeems` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `owner` int(11) NOT NULL,
  `referred_user` int(11) NOT NULL,
  `type` varchar(255) DEFAULT NULL,
  `status` tinyint(4) DEFAULT 0 COMMENT '0-Por Pagar , 1-Procesada OK',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=82 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bonus_redeems`
--

LOCK TABLES `bonus_redeems` WRITE;
/*!40000 ALTER TABLE `bonus_redeems` DISABLE KEYS */;
INSERT INTO `bonus_redeems` VALUES (78,2,4,'Solidary',0,'2024-06-27 13:57:40','2024-06-27 13:57:40'),(79,3,5,'Solidary',0,'2024-06-27 14:30:47','2024-06-27 14:30:47'),(80,3,6,'Solidary',0,'2024-07-01 15:19:50','2024-07-01 15:19:50'),(81,3,7,'Solidary',0,'2024-11-03 13:45:39','2024-11-03 13:45:39');
/*!40000 ALTER TABLE `bonus_redeems` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `charge_commisions`
--

DROP TABLE IF EXISTS `charge_commisions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `charge_commisions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `transfer_charge` varchar(191) NOT NULL,
  `withdraw_charge` varchar(191) NOT NULL,
  `level1_bonus` decimal(5,2) unsigned NOT NULL DEFAULT 0.00,
  `level2_bonus` decimal(5,2) unsigned NOT NULL DEFAULT 0.00,
  `level3_bonus` decimal(5,2) unsigned NOT NULL DEFAULT 0.00,
  `level4_bonus` decimal(5,2) unsigned NOT NULL DEFAULT 0.00,
  `level5_bonus` decimal(5,2) unsigned NOT NULL DEFAULT 0.00,
  `level1_consu` decimal(5,2) unsigned NOT NULL DEFAULT 0.00,
  `level2_consu` decimal(5,2) unsigned NOT NULL DEFAULT 0.00,
  `level3_consu` decimal(5,2) unsigned NOT NULL DEFAULT 0.00,
  `level4_consu` decimal(5,2) unsigned NOT NULL DEFAULT 0.00,
  `level5_consu` decimal(5,2) NOT NULL DEFAULT 0.00,
  `rest_bonus_for` tinyint(1) unsigned NOT NULL DEFAULT 0 COMMENT '0-Siguiente-Compresion-Dinamica, 1-Admin',
  `update_charge` varchar(191) DEFAULT NULL,
  `update_commision_tree` varchar(191) DEFAULT NULL,
  `update_text` longtext DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `charge_commisions`
--

LOCK TABLES `charge_commisions` WRITE;
/*!40000 ALTER TABLE `charge_commisions` DISABLE KEYS */;
INSERT INTO `charge_commisions` VALUES (1,'5','5',5.00,4.00,4.00,7.00,80.00,15.00,9.00,4.00,7.00,65.00,0,NULL,NULL,'<div><div><font size=\"4\"><b>Bienvenidos a Bigseer ,</b> estás recibiendo beneficios frecuentes y seguros, del desarrollo de las actividades empresariales autónomas que garantizan y respaldan cada plan que haz adquirido.<br></font></div></div>',NULL,'2024-11-06 06:08:33');
/*!40000 ALTER TABLE `charge_commisions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `crypto_transactions`
--

DROP TABLE IF EXISTS `crypto_transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `crypto_transactions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_from` int(11) NOT NULL,
  `user_to` int(11) NOT NULL,
  `wallet_from` varchar(255) NOT NULL,
  `wallet_to` varchar(255) NOT NULL DEFAULT '',
  `description` varchar(255) DEFAULT NULL,
  `amount` decimal(14,2) DEFAULT 0.00,
  `transaction_id_from` int(11) DEFAULT 0,
  `transaction_id_to` int(11) DEFAULT 0,
  `status` tinyint(4) DEFAULT 0 COMMENT '0-Generada, 1-En cola, 2-Procesada OK',
  `try` int(11) DEFAULT 0,
  `confirmation_date` datetime DEFAULT NULL,
  `confirmation_trans` varchar(255) DEFAULT '',
  `confirmation_json` longtext DEFAULT NULL,
  `confirmation_message` text DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `crypto_transactions`
--

LOCK TABLES `crypto_transactions` WRITE;
/*!40000 ALTER TABLE `crypto_transactions` DISABLE KEYS */;
/*!40000 ALTER TABLE `crypto_transactions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `deposits`
--

DROP TABLE IF EXISTS `deposits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `deposits` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `gateway_id` int(11) NOT NULL,
  `amount` decimal(14,2) NOT NULL,
  `status` varchar(191) NOT NULL DEFAULT '0' COMMENT '0 - Pendiente, 1 - Confirmada, 9 - Descartar',
  `trx` varchar(191) NOT NULL,
  `bcid` varchar(191) DEFAULT NULL,
  `bcam` varchar(191) DEFAULT NULL,
  `try` varchar(191) NOT NULL DEFAULT '0',
  `detail` text DEFAULT NULL,
  `aproved_by` int(11) DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `usd_amount` decimal(14,2) DEFAULT 0.00,
  `trx_charge` decimal(14,2) DEFAULT 0.00,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `deposits`
--

LOCK TABLES `deposits` WRITE;
/*!40000 ALTER TABLE `deposits` DISABLE KEYS */;
INSERT INTO `deposits` VALUES (1,6,9,100.00,'0','DP834118767',NULL,NULL,'0',NULL,0,'2024-07-01 23:03:19','2024-07-01 23:03:22',100.00,5.00),(2,4,7,1000.00,'0','DP1012448729',NULL,NULL,'0',NULL,0,'2024-07-02 15:27:16','2024-07-02 15:27:16',1000.00,0.00),(3,4,9,1000.00,'0','DP7187184',NULL,NULL,'0',NULL,0,'2024-07-04 20:08:26','2024-07-04 20:08:31',1000.00,50.00);
/*!40000 ALTER TABLE `deposits` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gateways`
--

DROP TABLE IF EXISTS `gateways`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gateways` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `gateimg` varchar(191) DEFAULT NULL,
  `minamo` varchar(191) NOT NULL,
  `maxamo` varchar(191) NOT NULL,
  `chargefx` varchar(191) NOT NULL,
  `chargepc` varchar(191) NOT NULL,
  `rate` varchar(191) NOT NULL,
  `val1` varchar(191) DEFAULT NULL,
  `val2` varchar(191) DEFAULT NULL,
  `val3` varchar(191) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gateways`
--

LOCK TABLES `gateways` WRITE;
/*!40000 ALTER TABLE `gateways` DISABLE KEYS */;
INSERT INTO `gateways` VALUES (3,'BlockChain','5a70961c5783f.png','10','20000','0.01','0.5','675410.98','YOUR API KEY FROM BLOCKCHAIN.INFO','YOUR XPUB FROM BLOCKCHAIN.INFO',NULL,NULL,NULL,NULL),(4,'Stripe','5a7ed16c4cf99.png','10','50000','5','2.5','80','sk_test_aat3tzBCCXXBkS4sxY3M8A1B','pk_test_AU3G7doZ1sbdpJLj0NaozPBu',NULL,NULL,NULL,NULL),(7,'Coin Payment','6678fd5ab4851.png','0','100000000','0','0','675410.98','db1d9f12444e65c921604e289a281c56',NULL,NULL,0,NULL,'2024-07-04 18:04:01'),(9,'Efectivo','5eb28a738c72d.jpg','50','10000','0','5','1','La transacción será aprobada por el administrador de la plataforma cuando el dinero sea recibido',NULL,NULL,1,NULL,'2024-06-24 09:12:20');
/*!40000 ALTER TABLE `gateways` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gateways_copy`
--

DROP TABLE IF EXISTS `gateways_copy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gateways_copy` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `gateimg` varchar(191) DEFAULT NULL,
  `minamo` varchar(191) NOT NULL,
  `maxamo` varchar(191) NOT NULL,
  `chargefx` varchar(191) NOT NULL,
  `chargepc` varchar(191) NOT NULL,
  `rate` varchar(191) NOT NULL,
  `val1` varchar(191) DEFAULT NULL,
  `val2` varchar(191) DEFAULT NULL,
  `val3` varchar(191) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gateways_copy`
--

LOCK TABLES `gateways_copy` WRITE;
/*!40000 ALTER TABLE `gateways_copy` DISABLE KEYS */;
INSERT INTO `gateways_copy` VALUES (1,'PayPal','5a7ed13a7d0d3.png','10','10000','2','2.5','80','rexrifat636@gmail.com',NULL,NULL,1,NULL,'2018-02-11 05:56:35'),(2,'Perfect Money','5a7ed14857f6d.png','10','20000','3','1','80','U5376900','G079qn4Q7XATZBqyoCkBteGRg',NULL,0,NULL,'2020-01-24 17:53:40'),(3,'BlockChain','5a70961c5783f.png','10','20000','0.01','0.5','675410.98','YOUR API KEY FROM BLOCKCHAIN.INFO','YOUR XPUB FROM BLOCKCHAIN.INFO',NULL,0,NULL,'2020-01-24 17:53:49'),(4,'Stripe','5a7ed16c4cf99.png','10','50000','5','2.5','80','sk_test_aat3tzBCCXXBkS4sxY3M8A1B','pk_test_AU3G7doZ1sbdpJLj0NaozPBu',NULL,1,NULL,'2018-02-12 01:30:47'),(5,'Skrill','5a70963c08257.jpg','10','50000','3','3','81','merchant@skrill','TheSoftKing',NULL,1,NULL,'2018-02-11 04:11:45'),(6,'Coingate','5a709647b797a.jpg','10','50000','3','3','83.30','1257','8wbQIWcXyRu1AHiJqtEhTY','Hr7LqFM83aJsZgbIVkoUW2Q4cGvlB05n',0,NULL,'2020-01-24 17:54:05'),(7,'Coin Payment','5a709659027e1.jpg','0','0','0','0','675410.98','db1d9f12444e65c921604e289a281c56',NULL,NULL,0,NULL,'2020-01-24 17:54:13'),(8,'Block IO','5a70966f55b80.jpg','0','10000','0','10','675410.98','7e13-0ee0-161c-882e','101201101201',NULL,0,'2018-01-27 12:00:00','2020-01-24 17:54:21');
/*!40000 ALTER TABLE `gateways_copy` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `generals`
--

DROP TABLE IF EXISTS `generals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `generals` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `web_title` varchar(191) NOT NULL,
  `currency` varchar(191) NOT NULL,
  `symbol` varchar(191) NOT NULL,
  `message` text NOT NULL,
  `email` varchar(191) NOT NULL,
  `mobile` varchar(191) NOT NULL,
  `status` int(191) NOT NULL DEFAULT 0,
  `about_text` text NOT NULL,
  `image` varchar(191) DEFAULT NULL,
  `theme` varchar(191) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `about_video_link` varchar(191) NOT NULL,
  `footer` varchar(191) NOT NULL,
  `footer_text` text NOT NULL,
  `policy` longtext NOT NULL,
  `terms` longtext NOT NULL,
  `address` text NOT NULL,
  `google_map_address` text NOT NULL,
  `start_date` date NOT NULL,
  `smsapi` text NOT NULL,
  `emailver` int(1) NOT NULL,
  `smsver` int(1) NOT NULL,
  `emessage` longtext NOT NULL,
  `esender` varchar(191) NOT NULL,
  `sec_color` varchar(191) NOT NULL,
  `email_nfy` int(1) DEFAULT 0,
  `sms_nfy` int(1) NOT NULL DEFAULT 0,
  `first_level_com` varchar(191) NOT NULL,
  `sec_level_com` varchar(191) NOT NULL,
  `third_level_com` varchar(191) NOT NULL,
  `first_level_name` varchar(191) NOT NULL,
  `sec_level_name` varchar(191) NOT NULL,
  `third_level_name` varchar(191) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `generals`
--

LOCK TABLES `generals` WRITE;
/*!40000 ALTER TABLE `generals` DISABLE KEYS */;
INSERT INTO `generals` VALUES (1,'Bigseer - Ai para predicciones','USD','USD','<span style=\"color: rgb(0, 0, 0); font-family: Verdana, sans-serif; font-size: 12px; text-align: center;\">W3Schools is optimized for learning, testing, and training. Examples might be simplified to improve reading and basic understanding. Tutorials, references, and examples are constantly reviewed to avoid errors, but we cannot warrant full correctness of all content. While using this site, you agree to have read and accepted our&nbsp;</span><a href=\"https://www.w3schools.com/about/about_copyright.asp\" style=\"box-sizing: inherit; background-color: rgb(255, 255, 255); color: inherit; font-family: Verdana, sans-serif; font-size: 12px; text-align: center;\">terms of use</a><span style=\"color: rgb(0, 0, 0); font-family: Verdana, sans-serif; font-size: 12px; text-align: center;\">,&nbsp;</span><a href=\"https://www.w3schools.com/about/about_privacy.asp\" style=\"box-sizing: inherit; background-color: rgb(255, 255, 255); color: inherit; font-family: Verdana, sans-serif; font-size: 12px; text-align: center;\">cookie and privacy policy</a><span style=\"color: rgb(0, 0, 0); font-family: Verdana, sans-serif; font-size: 12px; text-align: center;\">.&nbsp;</span><a href=\"https://www.w3schools.com/about/about_copyright.asp\" style=\"box-sizing: inherit; background-color: rgb(255, 255, 255); color: inherit; font-family: Verdana, sans-serif; font-size: 12px; text-align: center;\">Copyright 1999-2018</a><span style=\"color: rgb(0, 0, 0); font-family: Verdana, sans-serif; font-size: 12px; text-align: center;\">&nbsp;by Refsnes Data. All Rights Reserved.</span>','info@oxigenoglobal.com','',0,'','1522587150.jpg','AEC800',NULL,'2024-11-06 06:08:46','','2020 © Oxígeno Global','','','','','','2018-02-01','https://api.clockworksms.com/http/send.aspx',1,1,'<div style=\"text-align: center;\"><br></div><div style=\"text-align: center;\"><br></div><div style=\"text-align: center;\"><b><br></b></div><div style=\"text-align: center;\"><b><br></b></div><div style=\"text-align: center;\"><b>Hola {{name}},</b><br></div><div style=\"text-align: center;\"><br></div><div></div><div style=\"text-align: center;\">{{message}}</div><div style=\"text-align: center;\"><br></div><div style=\"text-align: center;\">Gracias, El equipo de Sodi Group&nbsp;<br></div><div style=\"text-align: center;\"><br></div><div style=\"text-align: center;\"><img src=\"https://i.imgur.com/ERQZBrL.png\" alt=\"\" align=\"none\"><br></div><div style=\"text-align: center;\"><br></div><div><br></div>','admin@people.grouprfg.com','f6f7f7',1,0,'0','0','0','0','0','0');
/*!40000 ALTER TABLE `generals` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `incomes`
--

DROP TABLE IF EXISTS `incomes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `incomes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `amount` decimal(14,2) NOT NULL,
  `description` varchar(255) NOT NULL,
  `type` tinyint(4) NOT NULL DEFAULT 1 COMMENT '1- Bono rapido, 2- Unilevel, 3-Consumo, 4-Solidario',
  `status` tinyint(4) DEFAULT 0 COMMENT '0 - Pendiente debe realizar consumo mínimo, 1 - Pagado, 2 - Pérdida de bono por no realizar consumo',
  `transaction_id` int(11) DEFAULT 0,
  `payment_date` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `type` (`type`),
  KEY `user_id_type` (`user_id`,`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `incomes`
--

LOCK TABLES `incomes` WRITE;
/*!40000 ALTER TABLE `incomes` DISABLE KEYS */;
/*!40000 ALTER TABLE `incomes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `membership_active`
--

DROP TABLE IF EXISTS `membership_active`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `membership_active` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL DEFAULT 0,
  `membership_id` int(11) NOT NULL DEFAULT 0,
  `start_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `finish_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `activation_transaction_id` int(11) DEFAULT 0,
  `activation_order_id` int(11) DEFAULT 0,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `membership_active`
--

LOCK TABLES `membership_active` WRITE;
/*!40000 ALTER TABLE `membership_active` DISABLE KEYS */;
/*!40000 ALTER TABLE `membership_active` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `membership_history`
--

DROP TABLE IF EXISTS `membership_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `membership_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `membership_id` int(11) DEFAULT NULL,
  `amount` decimal(14,2) DEFAULT 0.00,
  `cost` decimal(14,2) DEFAULT 0.00,
  `utility_for_admin` decimal(14,2) DEFAULT 0.00,
  `utility_for_network` decimal(14,2) DEFAULT NULL,
  `residue` decimal(14,2) DEFAULT 0.00,
  `status` tinyint(4) DEFAULT 0,
  `is_upgrade` tinyint(1) DEFAULT 0,
  `activation_transaction_id` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `membership_history`
--

LOCK TABLES `membership_history` WRITE;
/*!40000 ALTER TABLE `membership_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `membership_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `memberships`
--

DROP TABLE IF EXISTS `memberships`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `memberships` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tittle` varchar(255) DEFAULT NULL,
  `description` text NOT NULL,
  `max_level` tinyint(4) NOT NULL DEFAULT 3,
  `cost` decimal(14,2) NOT NULL DEFAULT 0.00,
  `utility_perc` decimal(5,2) NOT NULL DEFAULT 0.00,
  `price` decimal(14,2) NOT NULL DEFAULT 0.00,
  `quick_bonus_per` decimal(5,2) NOT NULL DEFAULT 0.00,
  `days_for_upgrade` tinyint(4) NOT NULL DEFAULT 8,
  `days_for_consu` tinyint(4) unsigned NOT NULL DEFAULT 1,
  `unilevel_perc` decimal(5,2) DEFAULT 0.00,
  `binary_perc` decimal(5,2) DEFAULT 0.00,
  `matrix_perc` decimal(5,2) DEFAULT 0.00,
  `capitalization_perc` decimal(5,2) DEFAULT 0.00,
  `product_id` int(11) DEFAULT 0,
  `product_qty` int(11) DEFAULT 1,
  `level1_bonus` decimal(10,2) DEFAULT NULL,
  `level2_bonus` decimal(10,2) DEFAULT NULL,
  `level3_bonus` decimal(10,2) DEFAULT NULL,
  `level4_bonus` decimal(10,2) DEFAULT NULL,
  `level5_bonus` decimal(10,2) DEFAULT NULL,
  `level1_consu` decimal(10,2) DEFAULT NULL,
  `level2_consu` decimal(10,2) DEFAULT NULL,
  `level3_consu` decimal(10,2) DEFAULT NULL,
  `level4_consu` decimal(10,2) DEFAULT NULL,
  `level5_consu` decimal(10,2) DEFAULT NULL,
  `image` text DEFAULT NULL,
  `status` tinyint(1) DEFAULT 0,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `memberships`
--

LOCK TABLES `memberships` WRITE;
/*!40000 ALTER TABLE `memberships` DISABLE KEYS */;
INSERT INTO `memberships` VALUES (1,'Plan semilla','<div><br>                                            </div><div>Paquete de inicio y en el plan de ganancias accede a: bono de Rápido y bono Unilevel hasta el 3 nivel.</div><br><div><b>Nota:</b> Sin limite de referidos Directos.&nbsp; Podrá hacer Actualización del plan durante los primeros 8 días conservando el valor pagado inicial, pasado este tiempo, deberá cancelar el valor total del Plan. <br></div><div><br></div><div>Para acceder a las ganancias de los bonos deberá estar activo en su donación mensual.\r\n                                            </div>',3,22.00,22.00,100.00,15.00,8,8,100.00,0.00,0.00,0.00,1,1,5.00,4.00,4.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,'5eb28c646b81b.jpg',1,NULL,'2020-05-13 13:41:49'),(2,'Plan Sembrador','<div><br>                                            </div><div>Paquete intermedio y en el plan de ganancias accede a: bono de Ingreso, bono Unilevel hasta el 4 nivel, Bono por consumo mensual hasta el 4 nivel.</div><br><div><b>Nota:</b> Sin limite de referidos Directos. Podrá hacer Actualización del plan durante los primeros 8 días conservando el valor pagado inicial, pasado este tiempo, deberá cancelar el valor total del Plan</div><div><br></div>Para acceder a las ganancias de los bonos deberá estar activo en su donación mensual.',4,88.00,22.00,550.00,15.00,8,8,100.00,0.00,0.00,0.00,1,4,5.00,4.00,4.00,7.00,0.00,15.00,9.00,4.00,7.00,NULL,'5eb28c889d40c.jpg',1,NULL,'2020-05-13 20:44:32'),(3,'Plan Cosecha','<div><br>                                            </div><div>Paquete de inicio mayor y en el plan de ganancias accede a: bono de Ingreso, bono Unilevel hasta el 5 nivel, Bono Consumo mensual hasta el 5 nivel,&nbsp; Bono Solidario. Además inicia calificaciones para los Bono Liderazgo y Bono Directivo.</div><div> <b><br></b></div><div><b>Nota: </b>Sin limite de referidos Directos. <br></div><div><br></div><div>Para acceder a las ganancias de los bonos deberá estar activo en su donación mensual.\r\n                                            </div>',5,176.00,22.00,1000.00,15.00,0,8,100.00,0.00,0.00,0.00,1,8,5.00,4.00,4.00,7.00,80.00,15.00,9.00,4.00,7.00,65.00,'5eb28c79628c0.jpg',1,NULL,'2020-05-16 01:56:30');
/*!40000 ALTER TABLE `memberships` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (2,'2014_10_12_100000_create_password_resets_table',1),(3,'2018_02_01_114204_create_admins_table',1),(4,'2018_02_01_114205_create_admin_password_resets_table',1),(5,'2017_12_18_061348_create_menus_table',2),(6,'2017_12_18_082712_create_logos_table',2),(7,'2017_12_18_092133_create_silders_table',2),(8,'2017_12_18_104142_create_services_table',2),(9,'2017_12_19_043718_create_testimonals_table',2),(10,'2017_12_19_063256_create_socials_table',2),(11,'2017_12_19_074614_create_footers_table',2),(12,'2018_01_25_220231_create_teams_table',2),(13,'2018_01_28_071556_create_contact_uses_table',2),(14,'2017_12_02_061213_create_generals_table',3),(15,'2018_02_05_064723_create_terms_policies_table',3),(16,'2018_02_05_070947_create_charge_commisions_table',3),(19,'2014_10_12_000000_create_users_table',4),(21,'2018_01_30_154801_create_tickets_table',6),(22,'2018_01_30_155004_create_ticket_comments_table',6),(23,'2017_12_28_072948_create_gateways_table',7),(25,'2017_12_28_105104_create_deposits_table',8),(27,'2018_02_11_062847_create_withdraws_table',9),(29,'2018_02_11_141223_create_withdraw_trasections_table',10),(30,'2018_02_12_062428_create_transactions_table',11),(31,'2018_02_18_102350_create_socials_table',12),(32,'2018_02_18_125849_create_member_belows_table',13),(33,'2018_02_18_135728_create_member_extras_table',14),(34,'2018_02_28_070550_create_incomes_table',15),(35,'2018_03_13_100618_create_packages_table',16),(36,'2018_03_13_124905_create_lending_logs_table',17),(37,'2018_03_31_084105_create_newletters_table',18),(38,'2018_03_31_100325_create_news_table',19);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `product_id` int(11) DEFAULT NULL,
  `qty` int(10) DEFAULT NULL,
  `price` decimal(14,2) DEFAULT NULL,
  `cost` decimal(14,2) DEFAULT NULL,
  `status` int(10) DEFAULT NULL,
  `transaction_id` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders`
--

LOCK TABLES `orders` WRITE;
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_resets` (
  `email` varchar(191) NOT NULL,
  `token` varchar(191) NOT NULL,
  `status` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_resets`
--

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
INSERT INTO `password_resets` VALUES ('guardcolombia@gmail.com','6ugzLJDaBJuR28edL67vtPhfujVNFk',0,'2024-11-02 11:43:05');
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `price` decimal(14,2) DEFAULT 0.00,
  `price2` decimal(14,2) DEFAULT 0.00,
  `price3` decimal(14,2) DEFAULT 0.00,
  `cost` decimal(14,2) DEFAULT 0.00,
  `status` tinyint(1) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products`
--

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES (1,'AQUAVIE PACA X 20 UNDS',NULL,15.00,0.00,0.00,7.42,1,'aquavie.png','2020-05-08 00:00:00','2020-05-08 00:00:00');
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ticket_comments`
--

DROP TABLE IF EXISTS `ticket_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ticket_comments` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ticket_id` varchar(191) NOT NULL,
  `type` int(11) NOT NULL,
  `comment` text NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ticket_comments`
--

LOCK TABLES `ticket_comments` WRITE;
/*!40000 ALTER TABLE `ticket_comments` DISABLE KEYS */;
/*!40000 ALTER TABLE `ticket_comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tickets`
--

DROP TABLE IF EXISTS `tickets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tickets` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ticket` varchar(191) NOT NULL,
  `subject` varchar(191) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `status` int(11) NOT NULL DEFAULT 1 COMMENT '1 - Abierto, 2 - Contestado, 3 - Respuesta de usuario, 9 - Cerrado',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tickets`
--

LOCK TABLES `tickets` WRITE;
/*!40000 ALTER TABLE `tickets` DISABLE KEYS */;
/*!40000 ALTER TABLE `tickets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transactions`
--

DROP TABLE IF EXISTS `transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `transactions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `trans_id` varchar(191) NOT NULL,
  `time` datetime NOT NULL,
  `description` text NOT NULL,
  `amount` decimal(14,2) NOT NULL DEFAULT 0.00,
  `charge` decimal(14,2) NOT NULL DEFAULT 0.00,
  `new_balance` decimal(14,2) NOT NULL DEFAULT 0.00,
  `type` int(4) NOT NULL DEFAULT 0,
  `model_ref` varchar(255) DEFAULT NULL,
  `model_id` int(10) unsigned DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `type` (`type`),
  KEY `model` (`model_ref`,`model_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transactions`
--

LOCK TABLES `transactions` WRITE;
/*!40000 ALTER TABLE `transactions` DISABLE KEYS */;
/*!40000 ALTER TABLE `transactions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transfers`
--

DROP TABLE IF EXISTS `transfers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `transfers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_from` int(11) NOT NULL DEFAULT 0,
  `user_to` int(11) NOT NULL DEFAULT 0,
  `amount` decimal(14,2) DEFAULT 0.00,
  `charge` decimal(14,2) DEFAULT 0.00,
  `status` tinyint(4) DEFAULT 0 COMMENT '0-Generada, 1-En cola, 2-Procesada OK',
  `transaction_id_from` int(11) DEFAULT 0,
  `transaction_id_to` int(11) DEFAULT 0,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transfers`
--

LOCK TABLES `transfers` WRITE;
/*!40000 ALTER TABLE `transfers` DISABLE KEYS */;
/*!40000 ALTER TABLE `transfers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `referrer_id` int(11) NOT NULL,
  `level` int(11) NOT NULL DEFAULT 0,
  `username` varchar(191) NOT NULL,
  `password` varchar(191) NOT NULL,
  `first_name` varchar(191) NOT NULL,
  `last_name` varchar(191) NOT NULL,
  `balance` decimal(14,2) NOT NULL DEFAULT 0.00,
  `join_date` date NOT NULL,
  `status` int(1) NOT NULL,
  `membership_id` int(11) DEFAULT 0,
  `membership_date` date DEFAULT NULL,
  `wallet` varchar(255) DEFAULT 'iowerfaioweuripaueruawpiuonawenurpaweupawiuPUIIO',
  `paid_status` int(1) DEFAULT NULL,
  `ver_status` int(1) DEFAULT NULL,
  `ver_code` varchar(191) DEFAULT NULL,
  `forget_code` varchar(191) DEFAULT NULL,
  `birth_day` date DEFAULT NULL,
  `email` varchar(191) NOT NULL,
  `mobile` varchar(191) NOT NULL,
  `street_address` varchar(191) NOT NULL,
  `city` varchar(191) NOT NULL,
  `country` varchar(191) NOT NULL,
  `post_code` varchar(191) DEFAULT '''000000''',
  `remember_token` varchar(100) DEFAULT NULL,
  `tauth` int(11) DEFAULT 0,
  `tfver` int(11) DEFAULT 0,
  `emailv` int(11) DEFAULT 0,
  `smsv` int(11) DEFAULT 0,
  `vsent` varchar(191) DEFAULT '0',
  `vercode` varchar(191) DEFAULT '0',
  `secretcode` varchar(191) DEFAULT '0',
  `image` varchar(191) DEFAULT '',
  `price_group` tinyint(4) DEFAULT 1 COMMENT '1-Normal, 2-Distribuidor, 3-Mayorista',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_username_unique` (`username`),
  UNIQUE KEY `users_email_unique` (`email`),
  KEY `referrer_id` (`referrer_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,0,0,'reserve_wallet','$2y$10$caHiULcR.hXPkspAwkjhc.OuYGHF.iBRoK1L6pGlV.XXCCcOuFnWa','Reserve','Wallet',0.00,'0000-00-00',1,0,NULL,'reserve_walletrCE11UtKkxWcEGn5P29ErcXpkBqblg6cECAs0sd5L9vLiDMeVCgDlGGfMQ8D',1,NULL,'','',NULL,'guardcolombia@gmail.com','9999999999','as','as','as','','rCE11UtKkxWcEGn5P29ErcXpkBqblg6cECAs0sd5L9vLiDMeVCgDlGGfMQ8D',0,1,1,1,'0','0','0','',1,NULL,'2024-11-06 06:05:16'),(2,0,1,'admin','$2y$10$J4YQg2BcdiXKx4jb3fFYu.2fIK7EmgFdquEz7r54RHpJyOrbijcQm','Oxigeno','Global',0.00,'0000-00-00',1,0,NULL,'adminrCE11UtKkxWcEGn5P29ErcXpkBqblg6cECAs0sd5L9vLiDMeVCgDlGGfMQ8D',1,NULL,'','',NULL,'admin@oxigenoglobal.net','8888888888','a','a','a','','B6maMhLe22Xevod9ArogpXouUuGsLrYSYk6non7p9fPEx6mfdC3Jplb3DTqi',0,1,1,1,'0','0','0','',1,NULL,'2024-11-06 06:05:16'),(3,2,0,'user1','$2y$10$Xnj9DfXtd2abfcZoDwmOsO5uICL.z.eTiefeMjAzMBfPGGukQGkU.','Shimei','Guerra',0.00,'2024-06-26',1,0,NULL,'324234234234234',0,0,'457512','0',NULL,'carpediem.sada@gmail.com','3002138024','Av 80 49-58','medellin','Colombia','\'000000\'','yNUldBnqzyEGU9tPLQ5jwUwQVPRG62tFZdTLR0dWIsfU24x9F3jIhAGnZ7nW',0,1,1,1,'0','0','0','1719523442.jpg',1,'2024-06-27 03:05:12','2024-11-06 06:05:16'),(4,2,0,'user2','$2y$10$/bi5PtGSDCOvCtIYUUV/se09hfkuYbTFcGNYY0Udiy32pF0OieSyi','user2','user2',0.00,'2024-06-27',1,0,NULL,'6262626262626',0,0,'514660','0',NULL,'user2@gmail.com','6262626','','medellin','Colombia','\'000000\'','tFROBfBf944iQdxDFtkHgwbzdjI4cmYsWBr5UN6PNMYZv2wUtnnNZ1CRkBwU',0,1,1,1,'0','0','0','',1,'2024-06-27 18:57:40','2024-11-06 06:05:16'),(5,3,0,'user3','$2y$10$TBx0p8uh5kc0VePxeCF05OiUQkCPuDi4KCSHf5n5.qaQ9VqM84VYq','user3','user3',0.00,'2024-06-27',1,0,NULL,'636sshsh',0,0,'516647','0',NULL,'test@gmail.com','7373737','','medellin','Colombia','\'000000\'','IUzslYB7XoA5rBvXTS8MwujjYtANEWQUnpdGIC9mjHaq8YCu0JlmQ4li03OC',0,1,1,1,'0','0','0','',1,'2024-06-27 19:30:47','2024-11-06 06:05:16'),(6,3,0,'lugiraldo2019','$2y$10$3TeI3IyA8ZW3pw310o4UVO1QpKmJ4X97Xe2oXEvsu5l/Zil44eeVK','alain','herrera',0.00,'2024-07-01',1,0,NULL,'00000',0,0,'865190','0',NULL,'lugiraldo2019@gmail.com','3046573009','','medellin','Colombia','\'000000\'','8sleNxYihcv1p3EZFJh8QVYQ7QZ0uVKU30uJbu5Hg0m5iixLym37ZpRupPSa',0,1,1,1,'0','0','0','',1,'2024-07-01 20:19:50','2024-11-06 06:05:16'),(7,3,0,'netwokrpost','$2y$10$Ibo3ibkoD.v/dWPNmxN8EOACzkGGwmfClgs7DOnAhNTKIbMMy7qKa','alain','herrera',0.00,'2024-11-03',1,0,NULL,'0xD14562135758d083698b0Ae04d1F355CC35D23F9',0,0,'659539','0',NULL,'network2post@gmail.com','3046573009','','medellin','Colombia','\'000000\'','OzPO4RfjTrxy9C18PI7eVb8tal4A6OJavELHbq8kfuVBnhFrXItyn8kjp6xQ',0,1,1,1,'0','0','0','',1,'2024-11-03 19:45:39','2024-11-06 06:05:16');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `withdraw_trasections`
--

DROP TABLE IF EXISTS `withdraw_trasections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `withdraw_trasections` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `withdraw_id` varchar(191) NOT NULL,
  `user_id` varchar(191) NOT NULL,
  `amount` varchar(191) NOT NULL,
  `charge` varchar(191) NOT NULL,
  `method_name` varchar(191) NOT NULL,
  `processing_time` varchar(191) NOT NULL,
  `detail` longtext DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `method_cur` varchar(191) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `withdraw_trasections`
--

LOCK TABLES `withdraw_trasections` WRITE;
/*!40000 ALTER TABLE `withdraw_trasections` DISABLE KEYS */;
/*!40000 ALTER TABLE `withdraw_trasections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `withdraws_method`
--

DROP TABLE IF EXISTS `withdraws_method`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `withdraws_method` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `image` varchar(191) DEFAULT NULL,
  `min_amo` varchar(191) NOT NULL,
  `max_amo` varchar(191) NOT NULL,
  `chargefx` varchar(191) NOT NULL,
  `chargepc` varchar(191) NOT NULL,
  `rate` varchar(191) NOT NULL,
  `processing_day` varchar(191) NOT NULL,
  `status` int(11) NOT NULL DEFAULT 1,
  `currency` varchar(191) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `withdraws_method`
--

LOCK TABLES `withdraws_method` WRITE;
/*!40000 ALTER TABLE `withdraws_method` DISABLE KEYS */;
INSERT INTO `withdraws_method` VALUES (10,'PayPal','1518420916.png','10','100000','2','5','1','5-7',1,'USD','2018-02-12 01:35:16','2024-07-02 06:16:52'),(11,'Paytm','1518421069.png','5','10000','5','1.5','1.29','7-10',0,'INR','2018-02-12 01:37:49','2020-01-24 19:27:05'),(12,'Strip','1518421113.png','10','100000','5','1.3','83','6-7',0,'USD','2018-02-12 01:38:33','2020-05-03 10:12:41'),(13,'Perfect Money','1518421160.png','5','100000','10','2.1','83','10-12',0,'USD','2018-02-12 01:39:20','2020-01-24 19:26:51');
/*!40000 ALTER TABLE `withdraws_method` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'admin_people'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-11-05 23:13:05
